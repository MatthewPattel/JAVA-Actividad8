## CS13304 - Computación Avanzada en Java
- Por: Jose Manuel Lopez Lujan, MIT

### CS13304T07 - Tema 8 Filters
 
#### Tema 8 -  Actividad 1